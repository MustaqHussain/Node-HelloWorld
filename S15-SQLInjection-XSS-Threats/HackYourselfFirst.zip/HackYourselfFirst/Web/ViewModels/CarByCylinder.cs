﻿namespace Web.ViewModels
{
  public class CarByCylinder
  {
    public int SupercarId { get; set; }

    public string Model { get; set; }
  }
}
﻿using System.Linq;
using System.Web.Mvc;
using Web.ViewModels;

namespace Web.Controllers
{
  public class CarsByCylindersController : Controller
  {
    private SupercarModelContext db = new SupercarModelContext();

    // GET: CarsByCylinders
    [ValidateInput(false)]
    public ActionResult Index(string cylinders)
    {
      var query = "SELECT SupercarId, Model FROM Supercar WHERE Cylinders = '" + cylinders + "'";

      var supercars = db.Database.SqlQuery<CarByCylinder>(query)
                        .Select(s => new CarByCylinder
                        {
                          SupercarId = s.SupercarId,
                          Model = s.Model
                        })
                        .OrderBy(s => s.Model);

      ViewBag.Title = string.Format("Supercars with a {0} engine layout", cylinders);

      return View(supercars);
    }
  }
}
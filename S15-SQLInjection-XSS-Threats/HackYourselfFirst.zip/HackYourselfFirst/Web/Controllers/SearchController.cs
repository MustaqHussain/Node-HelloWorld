﻿using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using Web.ViewModels;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
//using System.Data.DataSetExtensions;
using System;

namespace Web.Controllers
{
  public class SearchController : Controller
  {
    private SupercarModelContext db = new SupercarModelContext();

    //
    // GET: /Search
    [ValidateInput(false)]
    public ActionResult Index(string searchTerm)
    {
        var searchTermQuery = Request.QueryString["searchTerm"];
        var supercars = new object();

        string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString();
        
        // SQL Injection candidate
        string query = string.Format(@"SELECT SupercarId, m.Name, Model, PowerKw, TorqueNm, ZeroToOneHundredKmInSecs, TopSpeedKm FROM Supercar sc
                                        INNER JOIN Make m ON sc.[MakeId]=m.[MakeId]
                                        WHERE Name like '%{0}%' OR Model like '%{0}%' OR Description like '%{0}%' ORDER BY 2", searchTermQuery);
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            con.Open();
            using (SqlDataAdapter da = new SqlDataAdapter())
            {
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    DataSet ds = new DataSet();
                    da.SelectCommand = command;
                    da.Fill(ds, "ResultsTable");
                    DataTable myDataTable = ds.Tables["ResultsTable"];

                    supercars = (from s in myDataTable.AsEnumerable()
                                        select new Search
                                        {
                                            SupercarId = Convert.ToInt32(s["SupercarId"]),
                                            Make = s["Name"].ToString(),
                                            Model = s["Model"].ToString(),
                                            PowerKw = Convert.ToInt32(s["PowerKw"]),
                                            TorqueNm = Convert.ToInt32(s["TorqueNm"]),
                                            ZeroToOneHundredKmInSecs = Convert.ToDouble(s["ZeroToOneHundredKmInSecs"]),
                                            TopSpeedKm = Convert.ToInt32(s["TopSpeedKm"])
                                        }
                                ).ToList();
                }
            }
        }

        ViewBag.RawSearchTerm = searchTerm;


      ViewBag.SearchTerm = searchTerm;
      ViewBag.EncodedSearchTerm = searchTerm;
      return View(supercars);
    }

        //
        // GET: /Search
        [ValidateInput(false)]
        public ActionResult IndexSQLInjection(string searchTerm)
        {
            // Reading from query string to demonstrate HTTP/XXS verb tampering
            var searchTermQuery = Request.QueryString["searchTerm"];
            if (!string.IsNullOrEmpty(searchTermQuery) && searchTermQuery.Contains("<") && !searchTermQuery.Contains("harlem-shake"))
            {
                return View("IllegalChar");
            }

            var supercars = db.Supercars
                            .Where(s =>
                                    s.Make.Name.Contains(searchTerm)
                                    || s.Model.Contains(searchTerm)
                                    || s.Description.Contains(searchTerm))
                            .Include("Make")
                            .Select(s => new Search
                            {
                                SupercarId = s.SupercarId,
                                Make = s.Make.Name,
                                Model = s.Model,
                                PowerKw = s.PowerKw,
                                TorqueNm = s.TorqueNm,
                                ZeroToOneHundredKmInSecs = s.ZeroToOneHundredKmInSecs,
                                TopSpeedKm = s.TopSpeedKm
                            });
            ViewBag.RawSearchTerm = searchTerm;

            if (!string.IsNullOrEmpty(Request.QueryString["searchTerm"]))
            {
                searchTerm = searchTerm.Replace("<", "").Replace(">", "").Replace("/", "&#47;");
            }

            ViewBag.SearchTerm = searchTerm;
            ViewBag.EncodedSearchTerm = searchTerm;
            return View(supercars);
        }
    }
}

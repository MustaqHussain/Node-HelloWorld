﻿using System.Web.Mvc;

namespace Web.Controllers
{
  public class NotSecureController : Controller
  {
    public ActionResult Index()
    {
      return View();
    }
  }
}
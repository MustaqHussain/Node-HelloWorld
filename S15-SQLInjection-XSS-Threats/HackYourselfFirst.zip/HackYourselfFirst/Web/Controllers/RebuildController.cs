﻿using System.Web.Mvc;
using Web.RebuildDatabase;

namespace Web.Controllers
{
  public class RebuildController : Controller
  {
    public ActionResult Index()
    {
      DeleteAndPopulate.Rebuild();
      return View();
    }
  }
}

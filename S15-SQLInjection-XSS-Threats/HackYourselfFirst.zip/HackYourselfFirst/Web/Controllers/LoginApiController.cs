﻿using System.Linq;
using System.Web.Http;
using Web.Models;
using WebMatrix.WebData;

namespace Web.Controllers
{
  public class LoginApiController : ApiController
  {
    private SupercarModelContext db = new SupercarModelContext();

    [Route("api/login")]
    [HttpPost]
    public UserProfile Login(LoginModel login)
    {
      if (WebSecurity.Login(login.Email, login.Password, true))
      {
        return db.UserProfiles.Single(u => u.Email.Equals(login.Email));
      }

      return null;
    }
  }
}

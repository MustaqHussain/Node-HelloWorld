﻿using System.Collections.Generic;
using System.Web.Http;
using Web.Models;

namespace Web.Controllers
{
  public class AdminApiController : ApiController
  {
    private SupercarModelContext db = new SupercarModelContext();

    [Route("api/admin/users")]
    [HttpGet]
    public IEnumerable<UserProfile> Users()
    {
      return db.UserProfiles;
    }
  }
}

﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web.Http;
using Web.ViewModels;

namespace Web.Controllers
{
  public class SupercarApiController : ApiController
  {
    private SupercarModelContext db = new SupercarModelContext();

    [Route("api/supercar/leaderboard")]
    [HttpGet]
    public IEnumerable<LeaderboardSummary> Leaderboard(int? limitResults = 5)
    {
      return db.Supercars.Include("Votes").Select(s => new LeaderboardSummary
      {
        SupercarId = s.SupercarId,
        Make = s.Make.Name,
        Model = s.Model,
        PowerKw = s.PowerKw,
        TorqueNm = s.TorqueNm,
        ZeroToOneHundredKmInSecs = s.ZeroToOneHundredKmInSecs,
        TopSpeedKm = s.TopSpeedKm,
        WeightKg = s.WeightKg,
        EngineCc = s.EngineCc,
        EngineLayout = s.EngineLayout,
        Votes = s.Votes.Count
      }).OrderByDescending(s => s.Votes).Take(limitResults.Value);
    }

    [Route("api/supercar/{id}")]
    [HttpGet]
    public Leaderboard Get(int id)
    {
      var supercar = db.Supercars.SingleOrDefault(s => s.SupercarId.Equals(id));

      if (supercar == null)
      {
        throw new HttpResponseException(HttpStatusCode.NotFound);
      }

      return new Leaderboard
      {
        SupercarId = supercar.SupercarId,
        Make = supercar.Make.Name,
        Model = supercar.Model,
        PowerKw = supercar.PowerKw,
        TorqueNm = supercar.TorqueNm,
        ZeroToOneHundredKmInSecs = supercar.ZeroToOneHundredKmInSecs,
        TopSpeedKm = supercar.TopSpeedKm,
        WeightKg = supercar.WeightKg,
        EngineCc = supercar.EngineCc,
        EngineLayout = supercar.EngineLayout,
        Votes = supercar.Votes.Select(v => new Vote
        {
          Comment = v.Comments,
          Email = v.User.Email,
          Password = v.User.Password,
          FirstName = v.User.FirstName,
          LastName = v.User.LastName
        })
      };
    }
  }
}

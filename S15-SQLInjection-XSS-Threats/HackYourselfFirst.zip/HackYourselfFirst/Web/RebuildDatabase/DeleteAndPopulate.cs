﻿using System.Data.SqlClient;
using System.Web.Configuration;

namespace Web.RebuildDatabase
{
  public static class DeleteAndPopulate
  {
    public static void Rebuild()
    {
      var connString = WebConfigurationManager.ConnectionStrings["RebuildConnection"].ConnectionString;
      using (var conn = new SqlConnection(connString))
      {
        var command = new SqlCommand("RebuildDatabase", conn);
        command.Connection.Open();
        command.ExecuteNonQuery();
      }
    }
  }
}